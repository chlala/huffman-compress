#define _CRT_SECURE_NO_WARNINGS
#include "decompress.h"
#include "compress.h"
#include "huffman.h"
#include<string>
int nowfilelen = 0;
int filelen2 = 0;
int search(HuffmanTree HT, char *c, int i, int *num, int root)
{
	if (i >= strlen(c)) {
		return -1;
	}
	if (HT[root].lchild == -1 && HT[root].rchild == -1) {
		*num = root;
		return i;
	}
	if (c[i] == '0') {
		i++;
 		return search(HT, c, i, num, HT[root].lchild);
	}
	if (c[i] == '1') {
		i++;
		return search(HT, c, i, num, HT[root].rchild);
	}
}

int setfileName(char *filename,char *outfile)
{
	strcpy(outfile, filename);
	int namelen = strlen(filename);
	int i = namelen - 1;
	int j = 0;
	int t = 0;
	int tt = 0;
	char suf[10];
	char huf[10];
	while (filename[i] != '.')
	{
		huf[j] = filename[i];
		i--;
		j++;
	}
	huf[j] = '\0';
	if (strcmp(huf, "fuh") != 0) {
		cout << "���ļ����ܽ�ѹ!" << endl;
		return 0;
	}
	i--;
	t = i;
	while (filename[i] != '.')
	{
		i--;
	}
	tt = i;
	for (j = 0;i <= t;i++, j++) {
		suf[j] = filename[i];
	}
	suf[j] = '\0';
	outfile[tt] = '\0';
	strcat(outfile, "copy");
	strcat(outfile, suf);
	return 1;
}

void decompress(char *filename)
{
	FILE *in = fopen(filename, "rb");
	if (in == NULL) {
		cout << "���ļ�ʧ��!" << endl;
		return;
	}
	char outfile[256];
	int flag=setfileName(filename, outfile);
	if (flag == 0)
		return;
	FILE *out = fopen(outfile, "wb");
	HEAD head;
	char c[1024]="";
	char buf[10];
	int len = 0;
	int i;
	int filelen = 0;
	HuffmanTree HT = new hnode[511];
	HuffmanCode HC = new char *[511];
	int num = 0;
	int k;
	for (int i = 0;i < 511;i++) {
		HC[i] = new char[511];
	}
	int ch;
	fread(&head, sizeof(head), 1, in);
	filelen2 += sizeof(head.weight);
	for (int i = 0;i < 256;i++) {
		HT[i].weight = head.weight[i];
		filelen += HT[i].weight;
	}
	creatHuffmanTree(HT, 256);
	HuffmanCoding(510, HT, HC);
	cout << "���ڽ�ѹ�ļ�" << outfile << endl;
	while ((ch = getc(in)) != EOF)
	{
		filelen2++;
		_itoa(ch, buf, 2);
		int buflen = strlen(buf);
		if (buflen < 8) {
			int i;
			for (i = 7;i >= 8-buflen;i--) {
				buf[i] = buf[i - 8 + buflen];
			}
			while (i>=0)
			{
				buf[i] = '0';
				i--;
			}
			buf[8] = '\0';
		}
		strcat(c, buf);
		len = strlen(c);
		while (len > 10) {
			k = search(HT, c, 0, &num, 510);
			if (k != -1) {
				fputc(num, out);
				nowfilelen++;
				for (i = 0;i < len - k;i++) {
					c[i] = c[i + k];
				}
				c[i] = '\0';
			}
			len = strlen(c);
		}	
	}
	while(len > 0) {  
		k = search(HT, c, 0, &num, 510);
		if (k != -1) {
			nowfilelen++;
			fputc(num, out);
			for (i = 0;i < len - k;i++) {
				c[i] = c[i + k];
			}
			c[i] = '\0';
		}
		len = strlen(c);
		if (nowfilelen == filelen)
			break;
	}
	fclose(in);
	fclose(out);	
}

void getFileLen(int *len1, int *len2) {
	*len1 = filelen2;
	*len2 = nowfilelen;
	filelen2 = 0;
	nowfilelen = 0;
}