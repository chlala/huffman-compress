#define _CRT_SECURE_NO_WARNINGS
#include "huffman.h"

int select(HuffmanTree HT, int n)
{
	int minv = 0x7fffffff;
	int min = 0;
	for (int i = 0;i < n;i++) {
		if (HT[i].parent == -1 && HT[i].weight < minv) {

			minv = HT[i].weight;
			min = i;
		}
	}
	return min;
}

void creatHuffmanTree(HuffmanTree &HT, int n)
{
	int min1, min2;
	for (int i = 0;i < n - 1;i++) {
		min1 = select(HT, n + i);
		HT[min1].parent = n + i;
		min2 = select(HT, n + i);
		HT[min2].parent = n + i;
		HT[n + i].lchild = min1;
		HT[n + i].rchild = min2;
		HT[n + i].weight = HT[min1].weight + HT[min2].weight;
	}
}

void test1(HuffmanTree HT)
{
	for (int i = 0;i < 511;i++) {
		if (i == 6)
			cout << "......." << endl;
		if (i < 6 || i>505) {
			printf("t[%d]\t%d\t%d\t%d\t%d\n", i, HT[i].weight, HT[i].parent, HT[i].lchild, HT[i].rchild);

		}
	}
}

void testHuffmanTree(int root, HuffmanTree HT)
{
	cout << HT[root].weight << " ";
	if (HT[root].lchild != -1) {
		testHuffmanTree(HT[root].lchild, HT);
	}
	if (HT[root].rchild != -1) {
		testHuffmanTree(HT[root].rchild, HT);
	}
}

char code[256] = {' '};
int i = 0;
void HuffmanCoding(int root, HuffmanTree HT, HuffmanCode &HC)
{
	if (HT[root].lchild >= 0)
	{
		code[i] = '0';
		i++;
		HuffmanCoding(HT[root].lchild, HT, HC);
		i--;
	}
	if (HT[root].lchild == -1 && HT[root].rchild == -1)
	{
		code[i] = '\0';
		strcpy(HC[root], code);
//		printf("0x%02x %s\n", root, HC[root]);
	}
	if (HT[root].rchild >= 0)
	{
		code[i] = '1';
		i++;
		HuffmanCoding(HT[root].rchild, HT, HC);
		i--;
	}
}
