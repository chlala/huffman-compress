#define _CRT_SECURE_NO_WARNINGS
#include "compress.h"
#include "huffman.h"
#include<string>
int len1 = 0;
int len2 = 0;
int str2byte(char *str)
{
	int b = 0x00;
	for (int i = 0;i < 8;i++)
	{
		b = b << 1;
		if (str[i] == '1') {
			b = b | 0x01;
		}
	}
	return b;
}

void initHead(const char *filename, HEAD &head)
{
	strcpy(head.type, "HUF");
	head.length = 0;
	FILE *in = fopen(filename, "rb");
	int ch;
	while ((ch = fgetc(in)) != EOF) {
		head.weight[ch]++;
		head.length++;
	}
	fclose(in);
}

void enCode(char *filename, HuffmanCode HC, char *buffer, HuffmanTree HT)
{
	FILE *in = fopen(filename, "rb");
	if (in == NULL) {
		cout << "���ļ�ʧ��!" << endl;
		return;
	}
	char outName[256];
	strcpy(outName, filename);
	strcat(outName, ".huf");
	FILE *out = fopen(outName, "wb");
	int pos = 0;
	int ch = 0;
	int i;
	char cd[256] = "";
	int len = 0;
	HEAD head;
	int buf;
	initHead(filename, head);
	cout << "����ѹ���ļ�" << outName << endl;
	fwrite(&head, sizeof(head), 1, out);
	len2 += sizeof(head.weight);
	while ((ch = getc(in)) != EOF)
	{
		strcat(cd, HC[ch]);
		len = strlen(cd);
		while (len >= 8)
		{
			buf = str2byte(cd);
			fputc(buf, out);
			len2++;
			for (i = 0;i < len - 8;i++) {
				cd[i] = cd[i + 8];
			}
			cd[i] = '\0';
			len -= 8;
		}
	}
	if (strlen(cd) > 0) {
		buf = str2byte(cd);
		fputc(buf, out);
		len2++;
	}
	fclose(in);
	fclose(out);
}

void compress(char *filename)
{
	char buffer[10000];
	FILE *in = fopen(filename, "rb");
	if (in == NULL) {
		cout << "���ļ�ʧ��!" << endl;
		return;
	}
	char suf[10];
	int namelen = strlen(filename);
	int i, j;
	for (i = 0, j = namelen - 1;i < 3;i++, j--) {
		suf[i] = filename[j];
	}
	suf[i] = '\0';
	if (strcmp(suf, "fuh") == 0) {
		cout << "���ļ�����ѹ��!" << endl;
		return;
	}
	int ch;
	HuffmanTree HT = new hnode[511];
	HuffmanCode HC = new char *[511];
	for (int i = 0;i < 511;i++) {
		HC[i] = new char[511];
	}
	while ((ch = getc(in)) != EOF)
	{
		HT[ch].weight++;
		len1++;
	}
	fclose(in);
	creatHuffmanTree(HT, 256);
	HuffmanCoding(510, HT, HC);
/*	for (int i = 0;i < 256;i++) {
		if (i == 6)
			cout << "....... "<< endl;
		if (i < 6 || i>250) {
			printf("0x%02X %d\n", i, HT[i].weight);
		}
	}*/
//	test1(HT);
//	testHuffmanTree(510, HT);
	enCode(filename,HC,buffer,HT);
	delete HT;
	delete HC;
}

void getFileLength(int *lena, int *lenb) {
	*lena = len1;
	*lenb = len2;
	len1 = 0;
	len2 = 0;
}