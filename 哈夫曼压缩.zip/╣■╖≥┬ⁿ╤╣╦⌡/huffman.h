#ifndef HUFFMAN
#define HUFFMAN
#include<iostream>
using namespace std;

typedef struct hnode {
	int weight = 0;
	int parent = -1;
	int lchild = -1;
	int rchild = -1;
}node, *HuffmanTree;

typedef char **HuffmanCode;
int select(HuffmanTree HT, int n);
void creatHuffmanTree(HuffmanTree &HT, int n);
void test1(HuffmanTree HT);
void testHuffmanTree(int root, HuffmanTree HT);
void HuffmanCoding(int root, HuffmanTree HT, HuffmanCode &HC);
#endif