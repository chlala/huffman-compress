#ifndef COMPRESS
#define COMPRESS
#include<iostream>
#include "huffman.h"
using namespace std;
struct HEAD
{
	char type[4];
	int length;
	int weight[256] = { 0 };
};
int str2byte(char *str);
void enCode(char *filename, HuffmanCode HC, char *buffer, HuffmanTree HT);
void compress(char *filename);
void initHead(const char *filename, HEAD &head);
void getFileLength(int *lena, int *lenb);
#endif
