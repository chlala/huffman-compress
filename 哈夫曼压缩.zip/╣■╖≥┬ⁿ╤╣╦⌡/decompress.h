#ifndef DECOMPRESS
#define DECOMPRESS
#include<iostream>
#include "huffman.h"
using namespace std;
int search(HuffmanTree HT, char *c, int i, int *num, int root);
void decompress(char *filename);
void getFileLen(int *len1, int *len2);
int setfileName(char *filename, char *outfile);
#endif
